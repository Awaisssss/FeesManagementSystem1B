/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package feesmanagementsystem;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;

/**
 *
 * @author Admin
 */
public class Signup_PageTest {
    
    public Signup_PageTest() {
    }
    
    @BeforeClass
    public static void setUpClass() {
    }
    
    @AfterClass
    public static void tearDownClass() {
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }

    /**
     * Test of getId method, of class Signup_Page.
     */
    @Test
    public void testGetId() throws Exception {
        System.out.println("getId");
        Signup_Page instance = new Signup_Page();
        int expResult = 0;
        int result = instance.getId();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of validation method, of class Signup_Page.
     */
    @Test
    public void testValidation() {
        System.out.println("validation");
        Signup_Page instance = new Signup_Page();
        boolean expResult = false;
        boolean result = instance.validation();
        assertEquals(expResult, result);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of insertDetails method, of class Signup_Page.
     */
    @Test
    public void testInsertDetails() throws Exception {
        System.out.println("insertDetails");
        Signup_Page instance = new Signup_Page();
        instance.insertDetails();
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }

    /**
     * Test of main method, of class Signup_Page.
     */
    @Test
    public void testMain() {
        System.out.println("main");
        String[] args = null;
        Signup_Page.main(args);
        // TODO review the generated test code and remove the default call to fail.
        fail("The test case is a prototype.");
    }
    
}
