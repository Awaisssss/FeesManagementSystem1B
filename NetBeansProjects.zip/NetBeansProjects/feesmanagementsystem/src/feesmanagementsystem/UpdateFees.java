/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package feesmanagementsystem;

import java.awt.Color;
import java.sql.Connection;
import javax.swing.JOptionPane;
import java.lang.Exception;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.PreparedStatement;
import java.text.SimpleDateFormat;
import java.sql.*; 
/**
 *
 * @author Admin
 */
public class UpdateFees extends javax.swing.JFrame {

    /**
     * Creates new form AddFees
     */
    public UpdateFees()  {
        initComponents();
        displayDDFirst();
        fillComboBox();
        //getReceiptNo();
        setRecord();
        
        //int receiptNo = getReceiptNo();
        //txt_ReceiptNumber.setText(Integer.toString(receiptNo));
        
    }
    
    public void setRecord() {
        try{
            Connection con = DB.connect();
            Statement stmt=con.createStatement(); 
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select * from fees_details order by receipt_no desc limit 1");
            rs.next();
            
            txt_ReceiptNumber.setText(rs.getString("receipt_no"));
            combo_PaymentMode.setSelectedItem(rs.getString("payment_mode"));
            //dateChooser.setDate(rs.getDate("date"));
            txt_RollNo.setText(rs.getString("roll_no"));
            comboCourse.setSelectedItem(rs.getString("courses"));
            txt_Year1.setText(rs.getString("year1"));
            txt_Year2.setText(rs.getString("year2"));
            txt_ReceivedFrom.setText(rs.getString("student_name"));
            txt_Amount.setText(rs.getString("amount"));
            txt_Total.setText(rs.getString("total_amount"));
            txt_CGST.setText(rs.getString("cgst"));
            txt_SGST.setText(rs.getString("sgst"));
            txt_CourseName.setText(rs.getString("courses"));
            txt_TotalInWords.setText(rs.getString("total_in_words"));
            txt_Remark.setText(rs.getString("remark"));
            txt_ChequeNo.setText(rs.getString("cheque_no"));
            txt_DDNo.setText(rs.getString("dd_no"));
            txt_BankName.setText(rs.getString("bank_name"));
            
            /*8String paymentmode = rs.getString("payment_mode");
            if(paymentmode.equalsIgnoreCase("cash")) {
                lbl_chequedd.setText("");
                txt_chequedd.setText("");
                txt_bankname.setText("");
            }
            if(paymentmode.equalsIgnoreCase("cheque")) {
                lbl_chequedd.setText("Cheque number :");
                txt_chequedd.setText(rs.getString("cheque_no"));
                txt_bankname.setText(rs.getString("bank_name"));
            }
            if(paymentmode.equalsIgnoreCase("dd")) {
                lbl_chequedd.setText("DD number");
                txt_chequedd.setText(rs.getString("dd_no"));
                txt_bankname.setText(rs.getString("bank_name"));
            }
            if(paymentmode.equalsIgnoreCase("card")) {
                lbl_chequedd.setText("");
                txt_chequedd.setText(rs.getString(""));
                txt_bankname.setText(rs.getString("bank_name"));
            }*/
            
            }catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    public void displayDDFirst()
    {
        lbl_DDNo.setVisible(true);
        lbl_ChequeNo.setVisible(false);
        lbl_BankName.setVisible(true);
        
        txt_DDNo.setVisible(true);
        txt_ChequeNo.setVisible(false);
        txt_BankName.setVisible(true);
    }
    
    public boolean validation(){
        if(combo_PaymentMode.getSelectedItem().toString().equalsIgnoreCase("Cheque")){
            if(txt_ChequeNo.getText().equals("")){
                JOptionPane.showMessageDialog(this, "please enter cheque number");
            return false;
            }
        }
        if(combo_PaymentMode.getSelectedItem().toString().equalsIgnoreCase("Cheque")){
            if(txt_BankName.getText().equals("")){
                JOptionPane.showMessageDialog(this, "please enter bank name");
            return false;
            }
        }
        if(combo_PaymentMode.getSelectedItem().toString().equalsIgnoreCase("DD")){
            if(txt_DDNo.getText().equals("")){
                JOptionPane.showMessageDialog(this, "please enter DD number");
            return false;
            }
        }
        if(combo_PaymentMode.getSelectedItem().toString().equalsIgnoreCase("DD")){
            if(txt_BankName.getText().equals("")){
                JOptionPane.showMessageDialog(this, "please enter bank name");
            return false;
            }
        }
        if(combo_PaymentMode.getSelectedItem().toString().equalsIgnoreCase("Card")){
            if(txt_BankName.getText().equals("")){
                JOptionPane.showMessageDialog(this, "please enter bank name");
            return false;
            }
        }
        if (txt_ReceivedFrom.getText().equals("")){
            JOptionPane.showMessageDialog(this, "please enter user name");
            return false;
        }
        if(dateChooser.getDate() == null){
            JOptionPane.showMessageDialog(this, "please select a date");
            return false;
        }
        if(txt_Amount.getText().equals("")){
            JOptionPane.showMessageDialog(this, "please enter the amount");
            return false;
        }
        if(txt_RollNo.getText().equals("")){
            JOptionPane.showMessageDialog(this, "please enter roll number");
            return false;
        }
        return true;
    }
    
    public void fillComboBox() {
    
        try{
            Connection con = DB.connect();
            java.sql.PreparedStatement pst = con.prepareStatement("select cname from course");
            ResultSet rs = pst.executeQuery();
            while(rs.next()){
                comboCourse.addItem(rs.getString("cname"));
                
            }
            
        }catch(Exception e) {
        
    }
    }
    
    public int getReceiptNo(){
        
        int receiptNo = 0;
        try{
            Connection con = DB.connect();
            /*PreparedStatement pst;
            pst = (PreparedStatement) con.prepareStatement("select max(receipt_no) from fees_details");
            
            ResultSet rs = pst.executeQuery();
            //System.out.println(rs);
            if (rs.next() == true){
                receiptNo = rs.getInt("receipt_no");
            }*/
            
            Statement stmt=con.createStatement(); 
            stmt = con.createStatement();
            ResultSet rs = stmt.executeQuery("select max(receipt_no) from fees_details");
            //String receipt_no1 = "0";
            if (rs.next() == true) {
                receiptNo = rs.getInt(1);
            }
            //int value = Integer.parseInt(receipt_no1) + 1;
            /*while(rs.next()){
                receiptNo = Integer.parseInt(rs.getString("receipt_no"));
                System.out.print(rs.getString("receipt_no"));
            }*/
        }catch(Exception e){
            e.printStackTrace();
        }
        return receiptNo+1;
    }
    
    public String updateData(){
        
        //String status = "";
           
        int receiptNo = Integer.parseInt(txt_ReceiptNumber.getText());
        String studentName = txt_ReceivedFrom.getText();
        String RollNo = txt_RollNo.getText();
        String paymentMode = combo_PaymentMode.getSelectedItem().toString();
        String chequeNo = txt_ChequeNo.getText();
        String bankName = txt_BankName.getText();
        String ddNo = txt_DDNo.getText();
        String courseName = txt_CourseName.getText();
        float totalAmount = Float.parseFloat(txt_Total.getText());
        SimpleDateFormat dateFormat = new SimpleDateFormat("DD-MM-YYYY");
        String date = dateFormat.format(dateChooser.getDate());
        float initialAmount = Float.parseFloat(txt_Amount.getText());
        float cgst = Float.parseFloat(txt_CGST.getText());
        float sgst = Float.parseFloat(txt_SGST.getText());
        String totalInWords = txt_TotalInWords.getText();
        String remark = txt_Remark.getText();
        int year1 = Integer.parseInt(txt_Year1.getText());
        int year2 = Integer.parseInt(txt_Year2.getText());
        
        try{
            
         Connection con = DB.connect();
         
         
         //String query = "update fees_details values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
         //String query = "update fees_details values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
         String query = "update fees_details set student_name =?, payment_mode =?, cheque_no =?, bank_name =?, dd_no =?, courses =?, total_amount =?, date =?, amount =?, cgst =?, sgst =?, total_in_words =?, remark =?, year1 =?, year2 =?, roll_no =? where receipt_no =?";
         PreparedStatement pst = con.prepareStatement(query);
            
            /*Statement st = con.createStatement();
            int i = st.executeUpdate("insert into fees_details(receipt_no,student_name,payment_mode,cheque_no,bank_name,dd_no,courses,total_amount,date,amount,cgst,sgst,total_in_words,remark,year1,year2,roll_no) values("
                    + receiptNo + "," + studentName + "," + paymentMode + "," + chequeNo + "," + bankName + "," + ddNo + "," + courseName + "," + totalAmount + "," + date + "," + initialAmount + "," + cgst + "," + 
                    sgst + "," + totalInWords + "," + remark + "," + year1 + "," + year2 + "," + RollNo + ")");*/
            
            //System.out.println("update fees_details(receipt_no,snt_name,payment_mode,cheque_no,bank_name,dd_no,courses,total_amount,date,amount,cgst,sgst,total_in_words,remark,year1,year2,roll_no) values("
               //     + receiptNo + "," + studentName + "," + paymentMode + "," + chequeNo + "," + bankName + "," + ddNo + "," + courseName + "," + totalAmount + "," + date + "," + initialAmount + "," + cgst + "," + 
                 //   sgst + "," + totalInWords + "," + remark + "," + year1 + "," + year2 + "," + RollNo + ")");
            
            //INSERT INTO `fees_details`(`receipt_no`, `student_name`, `payment_mode`, `cheque_no`, `bank_name`, `dd_no`, `courses`, `total_amount`, `date`, `amount`, `cgst`, `sgst`, `total_in_words`, `remark`, `year1`, `year2`, `roll_no`) VALUES ([value-1],[value-2],[value-3],[value-4],[value-5],[value-6],[value-7],[value-8],[value-9],[value-10],[value-11],[value-12],[value-13],[value-14],[value-15],[value-16],[value-17])

            pst.setString(1, studentName);
            pst.setString(2, paymentMode);
            pst.setString(3, chequeNo);
            pst.setString(4, bankName);
            pst.setString(5, ddNo);
            pst.setString(6, courseName);
            pst.setFloat(7, totalAmount);
            pst.setString(8, date);
            pst.setFloat(9, initialAmount);
            pst.setFloat(10, cgst);
            pst.setFloat(11, sgst);
            pst.setString(12, totalInWords);
            pst.setString(13, remark);
            pst.setInt(14, year1);
            pst.setInt(15, year2);
            pst.setString(16, RollNo);
            pst.setInt(17, receiptNo);
            
            int i = pst.executeUpdate();
                if (i>0)
                {
                    JOptionPane.showMessageDialog(this, "record updated successfully");
                }
                else
                {
                    JOptionPane.showMessageDialog(this, "record updation failed");
                }
            //int n1=pst.executeUpdate();
            //if(n1>0)
            //{
              //  JOptionPane.showMessageDialog(this, "please enter roll number");
            //}
            
            //int rowCount = pst.executeUpdate();
                //if(rowCount==1){
                    //status="success";
                //}else{
                //status="failed";
                //}
        }catch(Exception e){
            JOptionPane.showMessageDialog(this,e);
        }
        //return status;
        return null;
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        entityManager = java.beans.Beans.isDesignTime() ? null : javax.persistence.Persistence.createEntityManagerFactory("fms?zeroDateTimeBehavior=convertToNullPU").createEntityManager();
        courseQuery = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT c FROM Course c");
        courseList = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : courseQuery.getResultList();
        courseQuery1 = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT c FROM Course c");
        courseList1 = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : courseQuery1.getResultList();
        courseQuery2 = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT c FROM Course c");
        courseList2 = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : courseQuery2.getResultList();
        courseQuery3 = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT c FROM Course c");
        courseList3 = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : courseQuery3.getResultList();
        signupQuery = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT s FROM Signup s");
        signupList = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : signupQuery.getResultList();
        courseQuery4 = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT c FROM Course c");
        courseList4 = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : courseQuery4.getResultList();
        courseQuery5 = java.beans.Beans.isDesignTime() ? null : entityManager.createQuery("SELECT c FROM Course c");
        courseList5 = java.beans.Beans.isDesignTime() ? java.util.Collections.emptyList() : courseQuery5.getResultList();
        panelsideBar = new javax.swing.JPanel();
        panelHome = new javax.swing.JPanel();
        btnHome = new javax.swing.JLabel();
        panelLogout = new javax.swing.JPanel();
        btnLogout = new javax.swing.JLabel();
        panelSearchRecord = new javax.swing.JPanel();
        btnSearchRecord = new javax.swing.JLabel();
        panelEditCourse = new javax.swing.JPanel();
        btnEditCourse = new javax.swing.JLabel();
        panelCourseList = new javax.swing.JPanel();
        btnCourseList = new javax.swing.JLabel();
        panelViewRecord = new javax.swing.JPanel();
        btnViewRecord = new javax.swing.JLabel();
        panelBack = new javax.swing.JPanel();
        btnBack = new javax.swing.JLabel();
        panelParent = new javax.swing.JPanel();
        lbl_ReceiptNo = new javax.swing.JLabel();
        lbl_PaymentMode = new javax.swing.JLabel();
        lbl_DDNo = new javax.swing.JLabel();
        lbl_ChequeNo = new javax.swing.JLabel();
        lbl_Date = new javax.swing.JLabel();
        dateChooser = new com.toedter.calendar.JDateChooser();
        txt_DDNo = new javax.swing.JTextField();
        panelChild = new javax.swing.JPanel();
        jLabel7 = new javax.swing.JLabel();
        txt_ReceivedFrom = new javax.swing.JTextField();
        lbl_RollNo = new javax.swing.JLabel();
        jLabel1 = new javax.swing.JLabel();
        txt_Year2 = new javax.swing.JTextField();
        txt_Year1 = new javax.swing.JTextField();
        lbl_ReceivedFrom = new javax.swing.JLabel();
        comboCourse = new javax.swing.JComboBox<>();
        jLabel11 = new javax.swing.JLabel();
        txt_RollNo = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jSeparator2 = new javax.swing.JSeparator();
        lbl_Course = new javax.swing.JLabel();
        jLabel13 = new javax.swing.JLabel();
        jLabel14 = new javax.swing.JLabel();
        txt_Total = new javax.swing.JTextField();
        txt_TotalInWords = new javax.swing.JTextField();
        txt_Amount = new javax.swing.JTextField();
        txt_CGST = new javax.swing.JTextField();
        txt_SGST = new javax.swing.JTextField();
        jSeparator3 = new javax.swing.JSeparator();
        txt_CourseName = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        jLabel16 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        txt_Remark = new javax.swing.JTextArea();
        btn_Print = new javax.swing.JButton();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        jLabel19 = new javax.swing.JLabel();
        lbl_BankName = new javax.swing.JLabel();
        combo_PaymentMode = new javax.swing.JComboBox<>();
        txt_ReceiptNumber = new javax.swing.JTextField();
        txt_BankName = new javax.swing.JTextField();
        txt_ChequeNo = new javax.swing.JTextField();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelsideBar.setBackground(new java.awt.Color(0, 0, 0));
        panelsideBar.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        panelHome.setBackground(new java.awt.Color(255, 255, 0));
        panelHome.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.yellow, java.awt.Color.white, null, null));
        panelHome.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnHome.setBackground(new java.awt.Color(0, 0, 0));
        btnHome.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnHome.setIcon(new javax.swing.ImageIcon(getClass().getResource("/feesmanagementsystem/images/home.png"))); // NOI18N
        btnHome.setText("  Home");
        btnHome.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnHomeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnHomeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnHomeMouseExited(evt);
            }
        });
        panelHome.add(btnHome, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, 280, 70));

        panelsideBar.add(panelHome, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 50, 330, 70));

        panelLogout.setBackground(new java.awt.Color(255, 255, 0));
        panelLogout.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.yellow, java.awt.Color.white, null, null));
        panelLogout.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnLogout.setBackground(new java.awt.Color(0, 0, 0));
        btnLogout.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnLogout.setIcon(new javax.swing.ImageIcon(getClass().getResource("/feesmanagementsystem/images/logout.png"))); // NOI18N
        btnLogout.setText("  Logout");
        btnLogout.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnLogoutMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnLogoutMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnLogoutMouseExited(evt);
            }
        });
        panelLogout.add(btnLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, 280, 70));

        panelsideBar.add(panelLogout, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 870, 330, 70));

        panelSearchRecord.setBackground(new java.awt.Color(255, 255, 0));
        panelSearchRecord.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.yellow, java.awt.Color.white, null, null));
        panelSearchRecord.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnSearchRecord.setBackground(new java.awt.Color(0, 0, 0));
        btnSearchRecord.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnSearchRecord.setIcon(new javax.swing.ImageIcon(getClass().getResource("/feesmanagementsystem/images/search2.png"))); // NOI18N
        btnSearchRecord.setText(" Search Record");
        btnSearchRecord.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnSearchRecordMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnSearchRecordMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnSearchRecordMouseExited(evt);
            }
        });
        panelSearchRecord.add(btnSearchRecord, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, 280, 70));

        panelsideBar.add(panelSearchRecord, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 180, 330, 70));

        panelEditCourse.setBackground(new java.awt.Color(255, 255, 0));
        panelEditCourse.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.yellow, java.awt.Color.white, null, null));
        panelEditCourse.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnEditCourse.setBackground(new java.awt.Color(0, 0, 0));
        btnEditCourse.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnEditCourse.setIcon(new javax.swing.ImageIcon(getClass().getResource("/feesmanagementsystem/images/edit2.png"))); // NOI18N
        btnEditCourse.setText("  Edit Course");
        btnEditCourse.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnEditCourseMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnEditCourseMouseExited(evt);
            }
        });
        panelEditCourse.add(btnEditCourse, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, 280, 70));

        panelsideBar.add(panelEditCourse, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 310, 330, 70));

        panelCourseList.setBackground(new java.awt.Color(255, 255, 0));
        panelCourseList.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.yellow, java.awt.Color.white, null, null));
        panelCourseList.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnCourseList.setBackground(new java.awt.Color(0, 0, 0));
        btnCourseList.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnCourseList.setIcon(new javax.swing.ImageIcon(getClass().getResource("/feesmanagementsystem/images/list.png"))); // NOI18N
        btnCourseList.setText(" Course List");
        btnCourseList.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnCourseListMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnCourseListMouseExited(evt);
            }
        });
        panelCourseList.add(btnCourseList, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, 280, 70));

        panelsideBar.add(panelCourseList, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 450, 330, 70));

        panelViewRecord.setBackground(new java.awt.Color(255, 255, 0));
        panelViewRecord.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.yellow, java.awt.Color.white, null, null));
        panelViewRecord.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnViewRecord.setBackground(new java.awt.Color(0, 0, 0));
        btnViewRecord.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnViewRecord.setIcon(new javax.swing.ImageIcon(getClass().getResource("/feesmanagementsystem/images/view all record.png"))); // NOI18N
        btnViewRecord.setText(" View All Record");
        btnViewRecord.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnViewRecordMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnViewRecordMouseExited(evt);
            }
        });
        panelViewRecord.add(btnViewRecord, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, 280, 70));

        panelsideBar.add(panelViewRecord, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 590, 330, 70));

        panelBack.setBackground(new java.awt.Color(255, 255, 0));
        panelBack.setBorder(javax.swing.BorderFactory.createBevelBorder(javax.swing.border.BevelBorder.RAISED, java.awt.Color.yellow, java.awt.Color.white, null, null));
        panelBack.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        btnBack.setBackground(new java.awt.Color(0, 0, 0));
        btnBack.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btnBack.setIcon(new javax.swing.ImageIcon(getClass().getResource("/feesmanagementsystem/images/left-arrow.png"))); // NOI18N
        btnBack.setText("  Back");
        btnBack.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                btnBackMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btnBackMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btnBackMouseExited(evt);
            }
        });
        panelBack.add(btnBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 0, 280, 70));

        panelsideBar.add(panelBack, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 730, 330, 70));

        getContentPane().add(panelsideBar, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 540, 1040));

        panelParent.setBackground(new java.awt.Color(255, 255, 0));
        panelParent.setForeground(new java.awt.Color(255, 255, 0));
        panelParent.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        lbl_ReceiptNo.setBackground(new java.awt.Color(0, 0, 0));
        lbl_ReceiptNo.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lbl_ReceiptNo.setText("Receipt number:");
        panelParent.add(lbl_ReceiptNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 60, 210, 40));

        lbl_PaymentMode.setBackground(new java.awt.Color(0, 0, 0));
        lbl_PaymentMode.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lbl_PaymentMode.setText("Mode of payment:");
        panelParent.add(lbl_PaymentMode, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 130, 230, 40));

        lbl_DDNo.setBackground(new java.awt.Color(0, 0, 0));
        lbl_DDNo.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lbl_DDNo.setText("DD number:");
        panelParent.add(lbl_DDNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 210, 210, 40));

        lbl_ChequeNo.setBackground(new java.awt.Color(0, 0, 0));
        lbl_ChequeNo.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lbl_ChequeNo.setText("Cheque number:");
        panelParent.add(lbl_ChequeNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 210, 210, 40));

        lbl_Date.setBackground(new java.awt.Color(0, 0, 0));
        lbl_Date.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lbl_Date.setText("Date:");
        panelParent.add(lbl_Date, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 60, 80, 40));

        dateChooser.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        panelParent.add(dateChooser, new org.netbeans.lib.awtextra.AbsoluteConstraints(1010, 60, 220, 40));

        txt_DDNo.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        txt_DDNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_DDNoActionPerformed(evt);
            }
        });
        panelParent.add(txt_DDNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 210, 270, 40));

        panelChild.setBackground(new java.awt.Color(255, 255, 0));
        panelChild.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        jLabel7.setBackground(new java.awt.Color(0, 0, 0));
        jLabel7.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel7.setText("The following payment for the year:");
        panelChild.add(jLabel7, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 90, 440, 40));

        txt_ReceivedFrom.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        txt_ReceivedFrom.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_ReceivedFromActionPerformed(evt);
            }
        });
        panelChild.add(txt_ReceivedFrom, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 20, 360, 40));

        lbl_RollNo.setBackground(new java.awt.Color(0, 0, 0));
        lbl_RollNo.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lbl_RollNo.setText("Roll no.:");
        panelChild.add(lbl_RollNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 20, 110, 40));

        jLabel1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel1.setText("to");
        panelChild.add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(610, 100, -1, -1));

        txt_Year2.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        txt_Year2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_Year2ActionPerformed(evt);
            }
        });
        panelChild.add(txt_Year2, new org.netbeans.lib.awtextra.AbsoluteConstraints(650, 90, 80, -1));

        txt_Year1.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        txt_Year1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_Year1ActionPerformed(evt);
            }
        });
        panelChild.add(txt_Year1, new org.netbeans.lib.awtextra.AbsoluteConstraints(510, 90, 80, -1));

        lbl_ReceivedFrom.setBackground(new java.awt.Color(0, 0, 0));
        lbl_ReceivedFrom.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lbl_ReceivedFrom.setText("Received from:");
        panelChild.add(lbl_ReceivedFrom, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 20, 210, 40));

        comboCourse.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        comboCourse.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                comboCourseActionPerformed(evt);
            }
        });
        panelChild.add(comboCourse, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 160, 200, 40));

        jLabel11.setBackground(new java.awt.Color(0, 0, 0));
        jLabel11.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel11.setText("Remark:");
        panelChild.add(jLabel11, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 540, 120, 40));

        txt_RollNo.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        txt_RollNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_RollNoActionPerformed(evt);
            }
        });
        panelChild.add(txt_RollNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(1050, 20, 110, 40));
        panelChild.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 270, 1230, 20));
        panelChild.add(jSeparator2, new org.netbeans.lib.awtextra.AbsoluteConstraints(840, 460, 430, 10));

        lbl_Course.setBackground(new java.awt.Color(0, 0, 0));
        lbl_Course.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lbl_Course.setText("Course:");
        panelChild.add(lbl_Course, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 160, 210, 40));

        jLabel13.setBackground(new java.awt.Color(0, 0, 0));
        jLabel13.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel13.setText("Sr. No.");
        panelChild.add(jLabel13, new org.netbeans.lib.awtextra.AbsoluteConstraints(50, 230, 210, 40));

        jLabel14.setBackground(new java.awt.Color(0, 0, 0));
        jLabel14.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel14.setText("1.");
        panelChild.add(jLabel14, new org.netbeans.lib.awtextra.AbsoluteConstraints(70, 290, 60, 40));

        txt_Total.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        txt_Total.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_TotalActionPerformed(evt);
            }
        });
        panelChild.add(txt_Total, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 470, 250, 40));

        txt_TotalInWords.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        txt_TotalInWords.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_TotalInWordsActionPerformed(evt);
            }
        });
        panelChild.add(txt_TotalInWords, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 470, 560, 40));

        txt_Amount.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        txt_Amount.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_AmountActionPerformed(evt);
            }
        });
        panelChild.add(txt_Amount, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 290, 250, 40));

        txt_CGST.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        txt_CGST.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_CGSTActionPerformed(evt);
            }
        });
        panelChild.add(txt_CGST, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 350, 250, 40));

        txt_SGST.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        txt_SGST.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_SGSTActionPerformed(evt);
            }
        });
        panelChild.add(txt_SGST, new org.netbeans.lib.awtextra.AbsoluteConstraints(920, 410, 250, 40));
        panelChild.add(jSeparator3, new org.netbeans.lib.awtextra.AbsoluteConstraints(40, 230, 1230, 20));

        txt_CourseName.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        txt_CourseName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_CourseNameActionPerformed(evt);
            }
        });
        panelChild.add(txt_CourseName, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 290, 560, 40));

        jLabel15.setBackground(new java.awt.Color(0, 0, 0));
        jLabel15.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel15.setText("Amount");
        panelChild.add(jLabel15, new org.netbeans.lib.awtextra.AbsoluteConstraints(990, 230, 210, 40));

        jLabel16.setBackground(new java.awt.Color(0, 0, 0));
        jLabel16.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel16.setText("Total in words:");
        panelChild.add(jLabel16, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 470, 190, 40));

        txt_Remark.setColumns(20);
        txt_Remark.setFont(new java.awt.Font("Monospaced", 1, 24)); // NOI18N
        txt_Remark.setRows(5);
        jScrollPane1.setViewportView(txt_Remark);

        panelChild.add(jScrollPane1, new org.netbeans.lib.awtextra.AbsoluteConstraints(220, 540, 520, 70));

        btn_Print.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        btn_Print.setText("Print");
        btn_Print.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_PrintActionPerformed(evt);
            }
        });
        panelChild.add(btn_Print, new org.netbeans.lib.awtextra.AbsoluteConstraints(1000, 550, -1, -1));

        jLabel17.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel17.setText("SGST 9%");
        panelChild.add(jLabel17, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 420, -1, -1));

        jLabel18.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel18.setText("CGST 9%");
        panelChild.add(jLabel18, new org.netbeans.lib.awtextra.AbsoluteConstraints(390, 360, -1, -1));

        jLabel19.setBackground(new java.awt.Color(0, 0, 0));
        jLabel19.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        jLabel19.setText("Head");
        panelChild.add(jLabel19, new org.netbeans.lib.awtextra.AbsoluteConstraints(410, 230, 210, 40));

        panelParent.add(panelChild, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 350, 1310, 800));

        lbl_BankName.setBackground(new java.awt.Color(0, 0, 0));
        lbl_BankName.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        lbl_BankName.setText("Bank name:");
        panelParent.add(lbl_BankName, new org.netbeans.lib.awtextra.AbsoluteConstraints(60, 290, 210, 40));

        combo_PaymentMode.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        combo_PaymentMode.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "DD", "Cheque", "Cash", "Card" }));
        combo_PaymentMode.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                combo_PaymentModeActionPerformed(evt);
            }
        });
        panelParent.add(combo_PaymentMode, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 130, 180, 40));

        txt_ReceiptNumber.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        txt_ReceiptNumber.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_ReceiptNumberActionPerformed(evt);
            }
        });
        panelParent.add(txt_ReceiptNumber, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 60, 180, 40));

        txt_BankName.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        txt_BankName.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_BankNameActionPerformed(evt);
            }
        });
        panelParent.add(txt_BankName, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 290, 360, 40));

        txt_ChequeNo.setFont(new java.awt.Font("Tahoma", 1, 24)); // NOI18N
        txt_ChequeNo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_ChequeNoActionPerformed(evt);
            }
        });
        panelParent.add(txt_ChequeNo, new org.netbeans.lib.awtextra.AbsoluteConstraints(290, 210, 270, 40));

        getContentPane().add(panelParent, new org.netbeans.lib.awtextra.AbsoluteConstraints(540, 0, 1310, 1040));

        pack();
        setLocationRelativeTo(null);
    }// </editor-fold>//GEN-END:initComponents

    private void btnHomeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnHomeMouseEntered
Color clr=new Color(0,76,153);
panelHome.setBackground(clr);        // TODO add your handling code here:
    }//GEN-LAST:event_btnHomeMouseEntered

    private void btnHomeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnHomeMouseExited
Color clr=new Color(255,255,0);
panelHome.setBackground(clr);        // TODO add your handling code here:
    }//GEN-LAST:event_btnHomeMouseExited

    private void btnLogoutMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLogoutMouseEntered
Color clr=new Color(0,76,153);
panelLogout.setBackground(clr);        // TODO add your handling code here:
    }//GEN-LAST:event_btnLogoutMouseEntered

    private void btnLogoutMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLogoutMouseExited
Color clr=new Color(255,255,0);
panelLogout.setBackground(clr);        // TODO add your handling code here:
    }//GEN-LAST:event_btnLogoutMouseExited

    private void btnSearchRecordMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSearchRecordMouseEntered
Color clr=new Color(0,76,153);
panelSearchRecord.setBackground(clr);         // TODO add your handling code here:
    }//GEN-LAST:event_btnSearchRecordMouseEntered

    private void btnSearchRecordMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSearchRecordMouseExited
Color clr=new Color(255,255,0);
panelSearchRecord.setBackground(clr);        // TODO add your handling code here:
    }//GEN-LAST:event_btnSearchRecordMouseExited

    private void btnEditCourseMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEditCourseMouseEntered
Color clr=new Color(0,76,153);
panelEditCourse.setBackground(clr);         // TODO add your handling code here:
    }//GEN-LAST:event_btnEditCourseMouseEntered

    private void btnEditCourseMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnEditCourseMouseExited
Color clr=new Color(255,255,0);
panelEditCourse.setBackground(clr);        // TODO add your handling code here:
    }//GEN-LAST:event_btnEditCourseMouseExited

    private void btnCourseListMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCourseListMouseEntered
Color clr=new Color(0,76,153);
panelCourseList.setBackground(clr);         // TODO add your handling code here:
    }//GEN-LAST:event_btnCourseListMouseEntered

    private void btnCourseListMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnCourseListMouseExited
Color clr=new Color(255,255,0);
panelCourseList.setBackground(clr);        // TODO add your handling code here:
    }//GEN-LAST:event_btnCourseListMouseExited

    private void btnViewRecordMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnViewRecordMouseEntered
Color clr=new Color(0,76,153);
panelViewRecord.setBackground(clr);         // TODO add your handling code here:
    }//GEN-LAST:event_btnViewRecordMouseEntered

    private void btnViewRecordMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnViewRecordMouseExited
Color clr=new Color(255,255,0);
panelViewRecord.setBackground(clr);        // TODO add your handling code here:
    }//GEN-LAST:event_btnViewRecordMouseExited

    private void btnBackMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBackMouseEntered
Color clr=new Color(0,76,153);
panelBack.setBackground(clr);         // TODO add your handling code here:
    }//GEN-LAST:event_btnBackMouseEntered

    private void btnBackMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBackMouseExited
Color clr=new Color(255,255,0);
panelBack.setBackground(clr);        // TODO add your handling code here:
    }//GEN-LAST:event_btnBackMouseExited

    private void txt_RollNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_RollNoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_RollNoActionPerformed

    private void txt_DDNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_DDNoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_DDNoActionPerformed

    private void txt_ReceivedFromActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_ReceivedFromActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_ReceivedFromActionPerformed

    private void txt_TotalActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_TotalActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_TotalActionPerformed

    private void txt_Year2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_Year2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_Year2ActionPerformed

    private void txt_Year1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_Year1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_Year1ActionPerformed

    private void txt_ReceiptNumberActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_ReceiptNumberActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_ReceiptNumberActionPerformed

    private void txt_BankNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_BankNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_BankNameActionPerformed

    private void txt_TotalInWordsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_TotalInWordsActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_TotalInWordsActionPerformed

    private void txt_AmountActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_AmountActionPerformed

        float amnt = Float.parseFloat(txt_Amount.getText());

        Float cgst = (float) (amnt * 0.09);
        Float sgst = (float) (amnt * 0.09);

        txt_CGST.setText(cgst.toString());
        txt_SGST.setText(sgst.toString());
        
        float total = amnt + cgst + sgst;
        txt_Total.setText(Float.toString(total));
        
        txt_TotalInWords.setText(NumberToWords.convert((int)total) + " Only");
        
    }//GEN-LAST:event_txt_AmountActionPerformed

    private void txt_CGSTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_CGSTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_CGSTActionPerformed

    private void txt_SGSTActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_SGSTActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_SGSTActionPerformed

    private void txt_CourseNameActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_CourseNameActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_CourseNameActionPerformed

    private void btn_PrintActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_PrintActionPerformed
    if(validation() == true)
    {
        updateData();
        PrintReceipt p = new PrintReceipt();
        p.show();
        this.dispose();
        //System.out.println("pressed");
        /*String result = insertData();
        if(result.equals("success")){
            JOptionPane.showMessageDialog(this, "record inserted successfully");
        }else{
            JOptionPane.showMessageDialog(this, "record insertion failed");}*/
    //JOptionPane.showMessageDialog(this, "validation successful");
    }        
    }//GEN-LAST:event_btn_PrintActionPerformed

    private void txt_ChequeNoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_ChequeNoActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_ChequeNoActionPerformed

    private void combo_PaymentModeActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_combo_PaymentModeActionPerformed
    if (combo_PaymentMode.getSelectedIndex() == 0){
        
        lbl_DDNo.setVisible(true);
        txt_DDNo.setVisible(true);
        lbl_ChequeNo.setVisible(false);
        txt_ChequeNo.setVisible(false);
        lbl_BankName.setVisible(true);
        txt_BankName.setVisible(true);
        
    }
    if (combo_PaymentMode.getSelectedIndex() == 1){
        
        lbl_DDNo.setVisible(false);
        txt_DDNo.setVisible(false);
        lbl_ChequeNo.setVisible(true);
        txt_ChequeNo.setVisible(true);
        lbl_BankName.setVisible(true);
        txt_BankName.setVisible(true);
    }
    if (combo_PaymentMode.getSelectedIndex() == 2){
        
        lbl_DDNo.setVisible(false);
        txt_DDNo.setVisible(false);
        lbl_ChequeNo.setVisible(false);
        txt_ChequeNo.setVisible(false);
        lbl_BankName.setVisible(false);
        txt_BankName.setVisible(false);
    }
    if (combo_PaymentMode.getSelectedIndex() == 3){
        
        lbl_DDNo.setVisible(false);
        txt_DDNo.setVisible(false);
        lbl_ChequeNo.setVisible(false);
        txt_ChequeNo.setVisible(false);
        lbl_BankName.setVisible(true);
        txt_BankName.setVisible(true);
    }
    }//GEN-LAST:event_combo_PaymentModeActionPerformed

    private void comboCourseActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_comboCourseActionPerformed
    txt_CourseName.setText(comboCourse.getSelectedItem().toString());        // TODO add your handling code here:
    }//GEN-LAST:event_comboCourseActionPerformed

    private void btnBackMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnBackMouseClicked
home home = new home();
home.show();
this.dispose();
// TODO add your handling code here:
    }//GEN-LAST:event_btnBackMouseClicked

    private void btnLogoutMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnLogoutMouseClicked
Login login = new Login();
login.show();
this.dispose();
    }//GEN-LAST:event_btnLogoutMouseClicked

    private void btnHomeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnHomeMouseClicked
home home = new home();
home.show();
this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_btnHomeMouseClicked

    private void btnSearchRecordMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_btnSearchRecordMouseClicked
SearchRecord search = new SearchRecord();
search.show();
this.dispose();        // TODO add your handling code here:
    }//GEN-LAST:event_btnSearchRecordMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(UpdateFees.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(UpdateFees.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(UpdateFees.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(UpdateFees.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new UpdateFees().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JLabel btnBack;
    private javax.swing.JLabel btnCourseList;
    private javax.swing.JLabel btnEditCourse;
    private javax.swing.JLabel btnHome;
    private javax.swing.JLabel btnLogout;
    private javax.swing.JLabel btnSearchRecord;
    private javax.swing.JLabel btnViewRecord;
    private javax.swing.JButton btn_Print;
    private javax.swing.JComboBox<String> comboCourse;
    private javax.swing.JComboBox<String> combo_PaymentMode;
    private java.util.List<feesmanagementsystem.Course> courseList;
    private java.util.List<feesmanagementsystem.Course> courseList1;
    private java.util.List<feesmanagementsystem.Course> courseList2;
    private java.util.List<feesmanagementsystem.Course> courseList3;
    private java.util.List<feesmanagementsystem.Course> courseList4;
    private java.util.List<feesmanagementsystem.Course> courseList5;
    private javax.persistence.Query courseQuery;
    private javax.persistence.Query courseQuery1;
    private javax.persistence.Query courseQuery2;
    private javax.persistence.Query courseQuery3;
    private javax.persistence.Query courseQuery4;
    private javax.persistence.Query courseQuery5;
    private com.toedter.calendar.JDateChooser dateChooser;
    private javax.persistence.EntityManager entityManager;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JSeparator jSeparator3;
    private javax.swing.JLabel lbl_BankName;
    private javax.swing.JLabel lbl_ChequeNo;
    private javax.swing.JLabel lbl_Course;
    private javax.swing.JLabel lbl_DDNo;
    private javax.swing.JLabel lbl_Date;
    private javax.swing.JLabel lbl_PaymentMode;
    private javax.swing.JLabel lbl_ReceiptNo;
    private javax.swing.JLabel lbl_ReceivedFrom;
    private javax.swing.JLabel lbl_RollNo;
    private javax.swing.JPanel panelBack;
    private javax.swing.JPanel panelChild;
    private javax.swing.JPanel panelCourseList;
    private javax.swing.JPanel panelEditCourse;
    private javax.swing.JPanel panelHome;
    private javax.swing.JPanel panelLogout;
    private javax.swing.JPanel panelParent;
    private javax.swing.JPanel panelSearchRecord;
    private javax.swing.JPanel panelViewRecord;
    private javax.swing.JPanel panelsideBar;
    private java.util.List<feesmanagementsystem.Signup> signupList;
    private javax.persistence.Query signupQuery;
    private javax.swing.JTextField txt_Amount;
    private javax.swing.JTextField txt_BankName;
    private javax.swing.JTextField txt_CGST;
    private javax.swing.JTextField txt_ChequeNo;
    private javax.swing.JTextField txt_CourseName;
    private javax.swing.JTextField txt_DDNo;
    private javax.swing.JTextField txt_ReceiptNumber;
    private javax.swing.JTextField txt_ReceivedFrom;
    private javax.swing.JTextArea txt_Remark;
    private javax.swing.JTextField txt_RollNo;
    private javax.swing.JTextField txt_SGST;
    private javax.swing.JTextField txt_Total;
    private javax.swing.JTextField txt_TotalInWords;
    private javax.swing.JTextField txt_Year1;
    private javax.swing.JTextField txt_Year2;
    // End of variables declaration//GEN-END:variables

   
}
