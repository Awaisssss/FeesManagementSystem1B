/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package feesmanagementsystem;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import java.math.BigInteger;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Admin
 */
@Entity
@Table(name = "signup", catalog = "fms", schema = "")
@NamedQueries({
    @NamedQuery(name = "Signup.findAll", query = "SELECT s FROM Signup s")
    , @NamedQuery(name = "Signup.findByUid", query = "SELECT s FROM Signup s WHERE s.uid = :uid")
    , @NamedQuery(name = "Signup.findByUname", query = "SELECT s FROM Signup s WHERE s.uname = :uname")
    , @NamedQuery(name = "Signup.findByPwd", query = "SELECT s FROM Signup s WHERE s.pwd = :pwd")
    , @NamedQuery(name = "Signup.findByEmail", query = "SELECT s FROM Signup s WHERE s.email = :email")
    , @NamedQuery(name = "Signup.findByContact", query = "SELECT s FROM Signup s WHERE s.contact = :contact")})
public class Signup implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "uid")
    private Integer uid;
    @Basic(optional = false)
    @Lob
    @Column(name = "fname")
    private String fname;
    @Basic(optional = false)
    @Lob
    @Column(name = "lname")
    private String lname;
    @Basic(optional = false)
    @Column(name = "uname")
    private String uname;
    @Basic(optional = false)
    @Column(name = "pwd")
    private String pwd;
    @Column(name = "email")
    private String email;
    @Column(name = "contact")
    private BigInteger contact;

    public Signup() {
    }

    public Signup(Integer uid) {
        this.uid = uid;
    }

    public Signup(Integer uid, String fname, String lname, String uname, String pwd) {
        this.uid = uid;
        this.fname = fname;
        this.lname = lname;
        this.uname = uname;
        this.pwd = pwd;
    }

    public Integer getUid() {
        return uid;
    }

    public void setUid(Integer uid) {
        Integer oldUid = this.uid;
        this.uid = uid;
        changeSupport.firePropertyChange("uid", oldUid, uid);
    }

    public String getFname() {
        return fname;
    }

    public void setFname(String fname) {
        String oldFname = this.fname;
        this.fname = fname;
        changeSupport.firePropertyChange("fname", oldFname, fname);
    }

    public String getLname() {
        return lname;
    }

    public void setLname(String lname) {
        String oldLname = this.lname;
        this.lname = lname;
        changeSupport.firePropertyChange("lname", oldLname, lname);
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        String oldUname = this.uname;
        this.uname = uname;
        changeSupport.firePropertyChange("uname", oldUname, uname);
    }

    public String getPwd() {
        return pwd;
    }

    public void setPwd(String pwd) {
        String oldPwd = this.pwd;
        this.pwd = pwd;
        changeSupport.firePropertyChange("pwd", oldPwd, pwd);
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        String oldEmail = this.email;
        this.email = email;
        changeSupport.firePropertyChange("email", oldEmail, email);
    }

    public BigInteger getContact() {
        return contact;
    }

    public void setContact(BigInteger contact) {
        BigInteger oldContact = this.contact;
        this.contact = contact;
        changeSupport.firePropertyChange("contact", oldContact, contact);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (uid != null ? uid.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Signup)) {
            return false;
        }
        Signup other = (Signup) object;
        if ((this.uid == null && other.uid != null) || (this.uid != null && !this.uid.equals(other.uid))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "feesmanagementsystem.Signup[ uid=" + uid + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
