/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package feesmanagementsystem;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Lob;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.persistence.Transient;

/**
 *
 * @author Admin
 */
@Entity
@Table(name = "fees_details", catalog = "fms", schema = "")
@NamedQueries({
    @NamedQuery(name = "FeesDetails.findAll", query = "SELECT f FROM FeesDetails f")
    , @NamedQuery(name = "FeesDetails.findByReceiptNo", query = "SELECT f FROM FeesDetails f WHERE f.receiptNo = :receiptNo")
    , @NamedQuery(name = "FeesDetails.findByStudentName", query = "SELECT f FROM FeesDetails f WHERE f.studentName = :studentName")
    , @NamedQuery(name = "FeesDetails.findByBankName", query = "SELECT f FROM FeesDetails f WHERE f.bankName = :bankName")
    , @NamedQuery(name = "FeesDetails.findByCourses", query = "SELECT f FROM FeesDetails f WHERE f.courses = :courses")
    , @NamedQuery(name = "FeesDetails.findByAmount", query = "SELECT f FROM FeesDetails f WHERE f.amount = :amount")
    , @NamedQuery(name = "FeesDetails.findByCgst", query = "SELECT f FROM FeesDetails f WHERE f.cgst = :cgst")
    , @NamedQuery(name = "FeesDetails.findBySgst", query = "SELECT f FROM FeesDetails f WHERE f.sgst = :sgst")
    , @NamedQuery(name = "FeesDetails.findByTotalInWords", query = "SELECT f FROM FeesDetails f WHERE f.totalInWords = :totalInWords")
    , @NamedQuery(name = "FeesDetails.findByRemark", query = "SELECT f FROM FeesDetails f WHERE f.remark = :remark")
    , @NamedQuery(name = "FeesDetails.findByYear1", query = "SELECT f FROM FeesDetails f WHERE f.year1 = :year1")
    , @NamedQuery(name = "FeesDetails.findByYear2", query = "SELECT f FROM FeesDetails f WHERE f.year2 = :year2")
    , @NamedQuery(name = "FeesDetails.findByRollNo", query = "SELECT f FROM FeesDetails f WHERE f.rollNo = :rollNo")})
public class FeesDetails implements Serializable {

    @Transient
    private PropertyChangeSupport changeSupport = new PropertyChangeSupport(this);

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @Column(name = "receipt_no")
    private Integer receiptNo;
    @Column(name = "student_name")
    private String studentName;
    @Lob
    @Column(name = "payment_mode")
    private String paymentMode;
    @Lob
    @Column(name = "cheque_no")
    private String chequeNo;
    @Column(name = "bank_name")
    private String bankName;
    @Lob
    @Column(name = "dd_no")
    private String ddNo;
    @Column(name = "courses")
    private String courses;
    @Lob
    @Column(name = "total_amount")
    private String totalAmount;
    @Basic(optional = false)
    @Lob
    @Column(name = "date")
    private String date;
    @Column(name = "amount")
    private Integer amount;
    // @Max(value=?)  @Min(value=?)//if you know range of your decimal fields consider using these annotations to enforce field validation
    @Column(name = "cgst")
    private Float cgst;
    @Column(name = "sgst")
    private Float sgst;
    @Column(name = "total_in_words")
    private String totalInWords;
    @Column(name = "remark")
    private String remark;
    @Column(name = "year1")
    private Integer year1;
    @Column(name = "year2")
    private Integer year2;
    @Basic(optional = false)
    @Column(name = "roll_no")
    private String rollNo;

    public FeesDetails() {
    }

    public FeesDetails(Integer receiptNo) {
        this.receiptNo = receiptNo;
    }

    public FeesDetails(Integer receiptNo, String date, String rollNo) {
        this.receiptNo = receiptNo;
        this.date = date;
        this.rollNo = rollNo;
    }

    public Integer getReceiptNo() {
        return receiptNo;
    }

    public void setReceiptNo(Integer receiptNo) {
        Integer oldReceiptNo = this.receiptNo;
        this.receiptNo = receiptNo;
        changeSupport.firePropertyChange("receiptNo", oldReceiptNo, receiptNo);
    }

    public String getStudentName() {
        return studentName;
    }

    public void setStudentName(String studentName) {
        String oldStudentName = this.studentName;
        this.studentName = studentName;
        changeSupport.firePropertyChange("studentName", oldStudentName, studentName);
    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        String oldPaymentMode = this.paymentMode;
        this.paymentMode = paymentMode;
        changeSupport.firePropertyChange("paymentMode", oldPaymentMode, paymentMode);
    }

    public String getChequeNo() {
        return chequeNo;
    }

    public void setChequeNo(String chequeNo) {
        String oldChequeNo = this.chequeNo;
        this.chequeNo = chequeNo;
        changeSupport.firePropertyChange("chequeNo", oldChequeNo, chequeNo);
    }

    public String getBankName() {
        return bankName;
    }

    public void setBankName(String bankName) {
        String oldBankName = this.bankName;
        this.bankName = bankName;
        changeSupport.firePropertyChange("bankName", oldBankName, bankName);
    }

    public String getDdNo() {
        return ddNo;
    }

    public void setDdNo(String ddNo) {
        String oldDdNo = this.ddNo;
        this.ddNo = ddNo;
        changeSupport.firePropertyChange("ddNo", oldDdNo, ddNo);
    }

    public String getCourses() {
        return courses;
    }

    public void setCourses(String courses) {
        String oldCourses = this.courses;
        this.courses = courses;
        changeSupport.firePropertyChange("courses", oldCourses, courses);
    }

    public String getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(String totalAmount) {
        String oldTotalAmount = this.totalAmount;
        this.totalAmount = totalAmount;
        changeSupport.firePropertyChange("totalAmount", oldTotalAmount, totalAmount);
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        String oldDate = this.date;
        this.date = date;
        changeSupport.firePropertyChange("date", oldDate, date);
    }

    public Integer getAmount() {
        return amount;
    }

    public void setAmount(Integer amount) {
        Integer oldAmount = this.amount;
        this.amount = amount;
        changeSupport.firePropertyChange("amount", oldAmount, amount);
    }

    public Float getCgst() {
        return cgst;
    }

    public void setCgst(Float cgst) {
        Float oldCgst = this.cgst;
        this.cgst = cgst;
        changeSupport.firePropertyChange("cgst", oldCgst, cgst);
    }

    public Float getSgst() {
        return sgst;
    }

    public void setSgst(Float sgst) {
        Float oldSgst = this.sgst;
        this.sgst = sgst;
        changeSupport.firePropertyChange("sgst", oldSgst, sgst);
    }

    public String getTotalInWords() {
        return totalInWords;
    }

    public void setTotalInWords(String totalInWords) {
        String oldTotalInWords = this.totalInWords;
        this.totalInWords = totalInWords;
        changeSupport.firePropertyChange("totalInWords", oldTotalInWords, totalInWords);
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        String oldRemark = this.remark;
        this.remark = remark;
        changeSupport.firePropertyChange("remark", oldRemark, remark);
    }

    public Integer getYear1() {
        return year1;
    }

    public void setYear1(Integer year1) {
        Integer oldYear1 = this.year1;
        this.year1 = year1;
        changeSupport.firePropertyChange("year1", oldYear1, year1);
    }

    public Integer getYear2() {
        return year2;
    }

    public void setYear2(Integer year2) {
        Integer oldYear2 = this.year2;
        this.year2 = year2;
        changeSupport.firePropertyChange("year2", oldYear2, year2);
    }

    public String getRollNo() {
        return rollNo;
    }

    public void setRollNo(String rollNo) {
        String oldRollNo = this.rollNo;
        this.rollNo = rollNo;
        changeSupport.firePropertyChange("rollNo", oldRollNo, rollNo);
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (receiptNo != null ? receiptNo.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof FeesDetails)) {
            return false;
        }
        FeesDetails other = (FeesDetails) object;
        if ((this.receiptNo == null && other.receiptNo != null) || (this.receiptNo != null && !this.receiptNo.equals(other.receiptNo))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "feesmanagementsystem.FeesDetails[ receiptNo=" + receiptNo + " ]";
    }

    public void addPropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.addPropertyChangeListener(listener);
    }

    public void removePropertyChangeListener(PropertyChangeListener listener) {
        changeSupport.removePropertyChangeListener(listener);
    }
    
}
