/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package feesmanagementsystem;

import java.sql.*;

/**
 *
 * @author Admin
 */
public class DB {
    public static Connection connect() throws ClassNotFoundException{
        Connection con = null;
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/fms","root", "");
        }catch(SQLException e){
            System.out.println(e);
        }
        return con;
    }

    static Connection connect(String jdbcderbylocalhost1527fees_management) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    static Connection connect(String jdbcmysqllocalhost3306fms, String root, String root0) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
